export default [
  require('/Users/meow/Desktop/html/fe-courses/node_modules/infima/dist/css/default/default.css'),
  require('/Users/meow/Desktop/html/fe-courses/node_modules/@docusaurus/theme-classic/lib/prism-include-languages'),
  require('/Users/meow/Desktop/html/fe-courses/node_modules/@docusaurus/theme-classic/lib/nprogress'),
  require('/Users/meow/Desktop/html/fe-courses/src/css/custom.css'),
];
