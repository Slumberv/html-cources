import React from 'react';
import ComponentCreator from '@docusaurus/ComponentCreator';

export default [
  {
    path: '/__docusaurus/debug',
    component: ComponentCreator('/__docusaurus/debug', 'a24'),
    exact: true
  },
  {
    path: '/__docusaurus/debug/config',
    component: ComponentCreator('/__docusaurus/debug/config', 'c9d'),
    exact: true
  },
  {
    path: '/__docusaurus/debug/content',
    component: ComponentCreator('/__docusaurus/debug/content', 'cd4'),
    exact: true
  },
  {
    path: '/__docusaurus/debug/globalData',
    component: ComponentCreator('/__docusaurus/debug/globalData', '958'),
    exact: true
  },
  {
    path: '/__docusaurus/debug/metadata',
    component: ComponentCreator('/__docusaurus/debug/metadata', '24a'),
    exact: true
  },
  {
    path: '/__docusaurus/debug/registry',
    component: ComponentCreator('/__docusaurus/debug/registry', '78e'),
    exact: true
  },
  {
    path: '/__docusaurus/debug/routes',
    component: ComponentCreator('/__docusaurus/debug/routes', '5ef'),
    exact: true
  },
  {
    path: '/markdown-page',
    component: ComponentCreator('/markdown-page', 'a81'),
    exact: true
  },
  {
    path: '/docs',
    component: ComponentCreator('/docs', 'd8f'),
    routes: [
      {
        path: '/docs/html-1/html-2',
        component: ComponentCreator('/docs/html-1/html-2', '205'),
        exact: true,
        sidebar: "tutorialSidebar"
      },
      {
        path: '/docs/html-1/html-3',
        component: ComponentCreator('/docs/html-1/html-3', '5b2'),
        exact: true,
        sidebar: "tutorialSidebar"
      },
      {
        path: '/docs/html-1/html-4',
        component: ComponentCreator('/docs/html-1/html-4', '066'),
        exact: true,
        sidebar: "tutorialSidebar"
      },
      {
        path: '/docs/html-1/html-5',
        component: ComponentCreator('/docs/html-1/html-5', '5a0'),
        exact: true,
        sidebar: "tutorialSidebar"
      },
      {
        path: '/docs/html-1/html-6',
        component: ComponentCreator('/docs/html-1/html-6', '431'),
        exact: true,
        sidebar: "tutorialSidebar"
      },
      {
        path: '/docs/html-1/html-7',
        component: ComponentCreator('/docs/html-1/html-7', '055'),
        exact: true,
        sidebar: "tutorialSidebar"
      },
      {
        path: '/docs/html-1/html-8',
        component: ComponentCreator('/docs/html-1/html-8', 'f46'),
        exact: true,
        sidebar: "tutorialSidebar"
      },
      {
        path: '/docs/html-1/html-9',
        component: ComponentCreator('/docs/html-1/html-9', 'adb'),
        exact: true,
        sidebar: "tutorialSidebar"
      },
      {
        path: '/docs/html-1/html-99',
        component: ComponentCreator('/docs/html-1/html-99', '20f'),
        exact: true,
        sidebar: "tutorialSidebar"
      },
      {
        path: '/docs/html-2/html-1',
        component: ComponentCreator('/docs/html-2/html-1', '752'),
        exact: true,
        sidebar: "tutorialSidebar"
      },
      {
        path: '/docs/html-2/html-3',
        component: ComponentCreator('/docs/html-2/html-3', '2c2'),
        exact: true,
        sidebar: "tutorialSidebar"
      },
      {
        path: '/docs/html-2/html-4',
        component: ComponentCreator('/docs/html-2/html-4', 'e39'),
        exact: true,
        sidebar: "tutorialSidebar"
      },
      {
        path: '/docs/html-2/html-5',
        component: ComponentCreator('/docs/html-2/html-5', '0f9'),
        exact: true,
        sidebar: "tutorialSidebar"
      }
    ]
  },
  {
    path: '/',
    component: ComponentCreator('/', '213'),
    exact: true
  },
  {
    path: '*',
    component: ComponentCreator('*'),
  },
];
